﻿using System.ComponentModel.DataAnnotations;

namespace WebTask3___Blog__.Models
{
    public class BlogType
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
    }
}
