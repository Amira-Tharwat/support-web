﻿using Microsoft.EntityFrameworkCore;
using WebTask3___Blog__.Models;

namespace WebTask3___Blog__.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Blog> blogs { get; set; }
        public DbSet<BlogType> blogTypes { get; set; }
      

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<BlogType>().HasData(
                new BlogType { Id = 1, Name = "comedy" },
                new BlogType { Id = 2, Name = "romantic" },
                new BlogType { Id = 3, Name = "horror" },
                new BlogType { Id = 4, Name = "scientific" }
                );

        }


    }
}
