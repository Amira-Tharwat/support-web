﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebTask3___Blog__.Data;
using WebTask3___Blog__.Models;

namespace WebTask3___Blog__.Controllers
{
    public class DashBoardController : Controller
    {
        private static List<Blog> _blogs = new List<Blog>();
        private static List<BlogType> _BlogTypes = new List<BlogType>();
        private readonly AppDbContext _db;

        public DashBoardController(AppDbContext db)
        {
            _db = db;
            _BlogTypes.Add(new BlogType { Id = 1, Name = "comedy" });
            _BlogTypes.Add(new BlogType { Id = 2, Name = "romantic" });
            _BlogTypes.Add(new BlogType { Id = 3, Name = "horror" });
            _BlogTypes.Add(new BlogType { Id = 4, Name = "scientific" });
        }
        public IActionResult Index()
        {
            return View();
        }
        #region AddBlog
        public IActionResult AddBlog()
        {
            return View();
        }
        [HttpPost]
        public IActionResult AddBlog(Blog blog)
        {

            _db.blogs.Add(blog);
            _db.SaveChanges();
            return RedirectToAction("index");

        }
        #endregion

        #region ViewBlogs

        public IActionResult ViewBlogs()
        {

            var blog = _db.blogs.Include(p => p.BlogType).ToList();
            return View(blog);
        }


        #endregion

        #region DeleteBlog
        public IActionResult DeleteBlog(int id)
        {
            Blog? blog = _db.blogs.FirstOrDefault(x => x.Id == id);
            _db.blogs.Remove(blog);
            _db.SaveChanges();
            return RedirectToAction("ViewBlogs");
        }

        #endregion

        #region EditBlog
        public IActionResult EditBlog(int id)
        {
            Blog blog = _db.blogs.FirstOrDefault(b => b.Id == id);
            return View(blog);
        }
        [HttpPost]
        public IActionResult EditBlog(Blog blog)
        {
            Blog newBlog = _db.blogs.FirstOrDefault(x => x.Id == blog.Id);
            newBlog.Name = blog.Name;
            newBlog.Description = blog.Description;
            newBlog.AuthorName = blog.AuthorName;
            newBlog.BlogTypeId = blog.BlogTypeId;
            _db.blogs.Update(newBlog);
            _db.SaveChanges();

            return RedirectToAction("index");

        }
        #endregion
    }
}
