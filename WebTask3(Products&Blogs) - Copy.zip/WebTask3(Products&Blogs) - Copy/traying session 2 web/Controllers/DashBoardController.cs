﻿using Microsoft.AspNetCore.Mvc;
using web_task_3.Models;

namespace web_task_3.Controllers
{
    public class DashBoardController : Controller
    {
        private static List<Product> _products = new List<Product>();
        private static List<Blog> _blogs = new List<Blog>();
        public IActionResult Index()
        {
            return View();
        }
        #region AddProduct
        public IActionResult AddProduct() { 
            return View();
        
        }
        [HttpPost]
        public IActionResult AddProduct(Product product)
        {
            int id;
            if(_products.Count ==0 )
            {
                id = 1;
            }
            else
            {
                id=_products.Max(x => x.Id)+1;
            }
            product.Id = id;
            _products.Add(product);
            return RedirectToAction("index");

        }
        #endregion

        #region GetAllProducts
        public IActionResult GetAllData() {
            return View(_products);
        }

        #endregion

        #region DeleteProduct
        public IActionResult Delete(int id)
        {
            Product product= _products.FirstOrDefault(x => x.Id == id);   
            _products.Remove(product);
            return RedirectToAction("GetAllData");
        }

        #endregion

        #region EditProduct
        public IActionResult Edit (int id)
        {
            Product product= _products.FirstOrDefault(y => y.Id == id);
            return View(product);
        }
        [HttpPost]
        
        public IActionResult Edit(Product product)
        {
            Product newProduct = _products.FirstOrDefault( x => x.Id == product.Id);
            newProduct.Name = product.Name;
            newProduct.Description = product.Description;
            newProduct.Price = product.Price;
            newProduct.EnableSize = product.EnableSize;
            newProduct.company.Id= product.company.Id;
            newProduct.Quantity = product.Quantity;

            return RedirectToAction("index");
        }
       

        #endregion

        #region AddBlog
        public IActionResult AddBlog()
        {
            return View();
        }
        [HttpPost]
        public IActionResult AddBlog(Blog blog)
        {
            int id;
            if (_blogs.Count == 0)
            {
                id = 1;
            }
            else
            {
                id = _blogs.Max(x => x.Id) + 1;
            }
            blog.Id = id;
            _blogs.Add(blog);
            return RedirectToAction("index");

        }
        #endregion

        #region GetAllBlogs

        public IActionResult GetAllDataBlogs()
        {
            return View(_blogs);
        }


        #endregion

        #region DeleteBlog
        public IActionResult DeleteBlog(int id)
        {
            Blog blog = _blogs.FirstOrDefault(x => x.Id == id);
            _blogs.Remove(blog);
            return RedirectToAction("GetAllDataBlogs");
        }

        #endregion

        #region EditBlog
        public IActionResult EditBlog(int id)
        {
            Blog blog = _blogs.FirstOrDefault(b => b.Id == id);
            return View(blog);
        }
        [HttpPost]
        public IActionResult EditBlog(Blog blog)
        {
            Blog newBlog = _blogs.FirstOrDefault(x => x.Id == blog.Id);
            newBlog.Name = blog.Name;
            newBlog.Description = blog.Description;
            newBlog.AuthorName = blog.AuthorName;
            newBlog.BlogType.Id = blog.BlogType.Id;
           

            return RedirectToAction("index");

        }
        #endregion
    }

}
