﻿namespace web_task_3.Models
{
    public class Company
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
