﻿namespace web_task_3.Models
{
    public class Blog
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string AuthorName { get; set; }
        public BlogType BlogType { get; set; }
    }
}
