﻿namespace web_task_3.Models
{
    public class BlogType
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
