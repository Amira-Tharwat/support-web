﻿namespace WebTask3___Blog__.Models
{
    public class BlogType
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
